# esp32_lib.py
# ESP32 TCP 通信库
"""
ESP32 TCP 通信库
功能：通过TCP连接ESP32，发送命令、查询状态、控制设备

使用方法：
    from esp32_lib import ESP32

    # 方式一：手动连接断开
    esp = ESP32("10.47.240.122", 8080)
    esp.connect()
    esp.forward()
    esp.disconnect()

    # 方式二：with语句（自动连接断开）
    with ESP32() as esp:
        esp.forward()

    # 方式三：快速测试
    esp = ESP32()
    esp.connect()
    esp.interactive()    # 进入交互模式

可用命令：
    esp.hello()          测试通信
    esp.forward()        正转
    esp.reverse()        反转
    esp.stop()           停止
    esp.auto()           自动模式（传感器控制）
    esp.speed(8)         设速度（0~13，远程模式才生效）
    esp.mode_local()     切就地模式（电位器控制）
    esp.mode_remote()    切远程模式（滑块控制）
    esp.unlock()         解除抱闸
    esp.lock()           上抱闸
    esp.status()         查询状态，返回字典
    esp.print_status()   查询并打印状态
    esp.send("xxx")      发送任意命令
    esp.is_connected()   返回是否连接
"""
import socket
import json
import threading


class ESP32:
    """
    ESP32 TCP 客户端

    默认配置：
        IP:   10.47.240.122
        端口: 8080

    用法：
        esp = ESP32()                    # 用默认配置
        esp = ESP32("192.168.1.100")     # 自定义IP
        esp = ESP32("192.168.1.100", 9090)  # 自定义IP和端口
    """

    def __init__(self, ip="10.47.240.122", port=8080):
        """
        初始化
        参数：
            ip:   ESP32的IP地址，默认10.47.240.122
            port: TCP端口，默认8080
        """
        self.ip = ip
        self.port = port
        self.sock = None
        self.connected = False
        self.lock = threading.Lock()

    # ============ 连接 ============
    def connect(self, timeout=3):
        """
        连接ESP32的TCP服务器
        参数：
            timeout: 超时秒数，默认3秒
        返回：
            True=成功  False=失败
        """
        try:
            self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.sock.settimeout(timeout)
            self.sock.connect((self.ip, self.port))
            self.connected = True
            return True
        except Exception:
            self.connected = False
            self.sock = None
            return False

    # ============ 断开 ============
    def disconnect(self):
        """断开连接"""
        if self.sock:
            try:
                self.sock.close()
            except Exception:
                pass
        self.connected = False
        self.sock = None

    # ============ 发送命令 ============
    def send(self, cmd, timeout=3):
        """
        发送命令并接收回复
        参数：
            cmd:     命令字符串，如 "dj 1"、"status"、"hello"
            timeout: 超时秒数
        返回：
            回复字符串  连接断开返回None  超时返回空字符串
        """
        with self.lock:
            try:
                if not self.connected:
                    return None
                self.sock.settimeout(timeout)
                self.sock.sendall((cmd + "\n").encode())
                
                response = self.sock.recv(4096).decode()
                lines = response.strip().split('\n')
                for line in reversed(lines):
                    line = line.strip()
                    if line:
                         return line
                return ""

            
            except socket.timeout:
                return ""
            except Exception:
                self.connected = False
                return None

    # ============ 查询状态 ============
    def status(self):
        """
        查询ESP32当前状态
        返回：
            字典 {"state":0, "speed":0, "pot":0, "sensor":0, "mode":0}
            state:   0=停止 1=正转 2=反转 3=自动
            speed:   舵机速度 0~13
            pot:     电位器位置 0~100%
            sensor:  0=检测到物体 1=未检测
            mode:    0=就地模式 1=远程模式
            连接断开返回None
        """
        response = self.send("status")
        if response is None:
            return None
        if response and response.startswith("{"):
            try:
                return json.loads(response)
            except json.JSONDecodeError:
                return None
        return None

    # ============ 打印当前状态 ============
    def print_status(self):
        """
        查询并格式化打印当前状态
        返回：字典或None
        """
        data = self.status()
        if data is None:
            print("[错误] 无法获取状态，连接可能断开")
            return None

        STATE_NAMES  = {0: "停止", 1: "正转", 2: "反转", 3: "自动"}
        SENSOR_NAMES = {0: "检测到！", 1: "未检测"}
        MODE_NAMES   = {0: "就地", 1: "远程"}

        state  = data.get("state", 0)
        speed  = data.get("speed", 0)
        pot    = data.get("pot", 0)
        sensor = data.get("sensor", 0)
        mode   = data.get("mode", 0)

        print(f"  运行状态:  {STATE_NAMES.get(state, '未知')}")
        print(f"  舵机速度:  {speed} / 13")
        print(f"  电位器:    {pot} %")
        print(f"  传感器:    {SENSOR_NAMES.get(sensor, '未知')}")
        print(f"  速度模式:  {MODE_NAMES.get(mode, '未知')}")

        return data

    # ============ 设备控制快捷方法 ============

    def forward(self):
        """正转：舵机正转 + 传送带正转"""
        return self.send("dj 1")

    def reverse(self):
        """反转：舵机反转 + 传送带反转"""
        return self.send("dj 2")

    def stop(self):
        """停止：舵机停 + 传送带停"""
        return self.send("dj 0")

    def auto(self):
        """
        自动模式：光纤传感器控制
        检测到物体（LOW）→ 延迟后停止
        没检测到（HIGH）→ 立即正转
        """
        return self.send("dj 3")

    def speed(self, val):
        """
        设置舵机速度（远程模式才生效）
        参数：
            val: 速度值 0~13，0=停，越大越快
        返回：回复字符串
        """
        val = max(0, min(13, int(val)))
        return self.send(f"speed {val}")

    def mode_local(self):
        """
        切换到就地模式
        速度由电位器控制，上位机滑块无效
        """
        return self.send("mode local")

    def mode_remote(self):
        """
        切换到远程模式
        速度由上位机滑块控制，电位器无效
        """
        return self.send("mode remote")

    def unlock(self):
        """
        解除抱闸
        舵机变自由，可以用手掰动
        注意：会先停止舵机，再切位置模式，最后解除
        """
        return self.send("en 0")

    def lock(self):
        """
        上抱闸
        舵机恢复控制，锁住当前位置
        注意：会上扭矩，再切轮模式
        """
        return self.send("en 1")

    def hello(self):
        """测试通信是否正常，返回ESP32的回复"""
        return self.send("hello")

    # ============ 状态查询 ============

    def is_connected(self):
        """返回是否已连接到ESP32"""
        return self.connected

    # ============ 交互模式 ============
    def interactive(self):
        """
        进入交互模式：终端里手动输入指令
        输入quit退出
        """
        print()
        print("=" * 45)
        print("  ESP32 交互模式")
        print("=" * 45)
        print("  hello      测试通信")
        print("  dj 0       停止")
        print("  dj 1       正转")
        print("  dj 2       反转")
        print("  dj 3       自动模式")
        print("  status     查询状态")
        print("  speed 8    设速度（远程模式）")
        print("  mode local  切就地模式")
        print("  mode remote 切远程模式")
        print("  en 0       解除抱闸")
        print("  en 1       上抱闸")
        print("  quit       退出")
        print("=" * 45)
        print()

        while True:
            try:
                cmd = input("> ").strip()
                if not cmd:
                    continue
                if cmd.lower() == "quit":
                    print("退出")
                    break
                response = self.send(cmd)
                if response is None:
                    print("[连接断开]")
                    break
                if response:
                    print(response)
            except KeyboardInterrupt:
                print("\n退出")
                break

    # ============ with语句支持 ============
    def __enter__(self):
        """with语句自动连接"""
        self.connect()
        return self

    def __exit__(self, *args):
        """with语句自动断开"""
        self.disconnect()