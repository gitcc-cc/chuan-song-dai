# 调试时：单独用
from esp32_lib import ESP32
esp = ESP32()
esp.connect()
esp.interactive()       # 手动测试各种指令

# # 正式程序：直接调用
# from esp32_lib import ESP32
# esp = ESP32()
# esp.connect()
# esp.forward()           # 不卡，瞬间执行
# esp.speed(8)