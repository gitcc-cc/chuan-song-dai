#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ESP32 控制中心 - PyQt5 微信风格
功能：TCP连接ESP32，实时状态显示，远程控制舵机+传送带
速度模式：就地（电位器）/ 远程（滑块），默认就地
快捷键：Esc 退出全屏
"""
from esp32_lib import ESP32
import json
import threading
from datetime import datetime
from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QGridLayout, QLabel, QPushButton, QSlider, QLineEdit, QTextEdit,
    QFrame, QGroupBox, QMessageBox, QSplitter
)
from PyQt5.QtCore import Qt, QTimer, pyqtSignal, QObject
from PyQt5.QtGui import QFont, QColor, QPalette

# ============ 默认配置 ============
DEFAULT_BROKER = "127.0.0.1"
DEFAULT_PORT = 1883
POLL_INTERVAL = 2000  # 状态轮询间隔（毫秒）

# ============ 微信风格样式表（字体加大） ============
STYLE = """
QMainWindow {
    background-color: #ededed;
}
QWidget {
    background-color: #ededed;
    color: #333333;
    font-family: 'Microsoft YaHei', 'Segoe UI', sans-serif;
    font-size: 16px;
}
QGroupBox {
    background-color: #ffffff;
    border: 1px solid #e0e0e0;
    border-radius: 8px;
    margin-top: 0px;
    padding-top: 35px;
    font-size: 17px;
    color: #333333;
    font-weight: bold;
}
QGroupBox::title {
    subcontrol-origin: margin;
    subcontrol-position: top left;
    left: 15px;
    top: 8px;
    padding: 4px 10px;
    color: #333333;
}
QLabel {
    background-color: transparent;
    font-size: 16px;
    color: #333333;
}
QPushButton {
    background-color: #ffffff;
    color: #333333;
    border: 1px solid #e0e0e0;
    border-radius: 6px;
    padding: 10px 18px;
    font-size: 15px;
    font-weight: bold;
}
QPushButton:hover {
    background-color: #f5f5f5;
    border-color: #07C160;
}
QPushButton:pressed {
    background-color: #e8e8e8;
}
QSlider::groove:horizontal {
    height: 6px;
    background: #e0e0e0;
    border-radius: 3px;
}
QSlider::handle:horizontal {
    background: #07C160;
    border: none;
    width: 22px;
    height: 22px;
    margin: -8px 0;
    border-radius: 11px;
}
QSlider::sub-page:horizontal {
    background: #07C160;
    border-radius: 3px;
}
QLineEdit {
    background-color: #ffffff;
    color: #333333;
    border: 1px solid #e0e0e0;
    border-radius: 6px;
    padding: 8px 12px;
    font-size: 16px;
    selection-background-color: #07C160;
}
QLineEdit:focus {
    border-color: #07C160;
}
QTextEdit {
    background-color: #f5f5f5;
    color: #333333;
    border: 1px solid #e0e0e0;
    border-radius: 6px;
    font-size: 14px;
    padding: 8px;
    selection-background-color: #07C160;
}
"""


# ============================================================
#  TCP 客户端（支持动态IP/端口）
# ============================================================
class ESP32Client:

    def __init__(self):
        
        self.client = ESP32()
        self.connected = False

    def connect(self, broker=None, port=None):
        if self.client.is_connected():
            self.client.disconnect()
        self.client = ESP32(broker=broker or DEFAULT_BROKER)
        result = self.client.connect(timeout=5)
        self.connected = result
        return result

    def disconnect(self):
        self.client.disconnect()
        self.connected = False

    def send_cmd(self, cmd):
        if not self.connected:
            return None
        return self.client.send(cmd)

    def is_connected(self):
        return self.connected

class WorkerSignals(QObject):
    connected = pyqtSignal()
    disconnected = pyqtSignal()
    connect_failed = pyqtSignal(str)
    status_update = pyqtSignal(dict)
    log_message = pyqtSignal(str)


# ============================================================
#  主窗口
# ============================================================
class ESP32MainWindow(QMainWindow):

    def __init__(self):
        super().__init__()
        self.client = ESP32Client()
        self.signals = WorkerSignals()

        self.current_data = {"state": 0, "speed": 0, "pot": 0, "sensor": 0, "mode": 0}
        self.speed_mode = 0
        self.slider_updating = False

        self.setWindowTitle("ESP32 控制中心")
        self.setStyleSheet(STYLE)

        self._create_ui()

        self.signals.connected.connect(self._on_connected)
        self.signals.disconnected.connect(self._on_disconnected)
        self.signals.connect_failed.connect(self._on_connect_failed)
        self.signals.status_update.connect(self._update_display)
        self.signals.log_message.connect(self._append_log)


    # ============ 创建界面 ============
    def _create_ui(self):
        central = QWidget()
        self.setCentralWidget(central)

        main_layout = QVBoxLayout(central)
        main_layout.setSpacing(8)
        main_layout.setContentsMargins(10, 10, 10, 10)

        # ---------- 顶栏：标题 + IP输入 + 连接按钮 + 时钟 + 状态 ----------
        header = QFrame()
        header.setStyleSheet("background-color: #ffffff; border-bottom: 1px solid #e0e0e0; border-radius: 0px;")
        header.setFixedHeight(65)
        header_layout = QHBoxLayout(header)
        header_layout.setContentsMargins(15, 8, 15, 8)

        title = QLabel("ESP32 控制中心")
        title.setFont(QFont("Microsoft YaHei", 18, QFont.Bold))
        title.setStyleSheet("color: #333333; border: none;")
        header_layout.addWidget(title)

        header_layout.addSpacing(30)

        # IP输入
        ip_label = QLabel("IP:")
        ip_label.setStyleSheet("color: #333333; border: none; font-size: 15px; font-weight: bold;")
        header_layout.addWidget(ip_label)

        self.broker_entry = QLineEdit(DEFAULT_BROKER)
        self.broker_entry.setFixedWidth(160)
        self.broker_entry.setStyleSheet(
            "QLineEdit{background:#f5f5f5; border:1px solid #e0e0e0; border-radius:6px;"
            "padding:6px 10px; font-size:15px;}"
            "QLineEdit:focus{border-color:#07C160;}"
        )
        header_layout.addWidget(self.broker_entry)

        # 端口输入
        port_label = QLabel("端口:")
        port_label.setStyleSheet("color: #333333; border: none; font-size: 15px; font-weight: bold;")
        header_layout.addWidget(port_label)

        self.port_entry = QLineEdit(str(DEFAULT_PORT))
        self.port_entry.setFixedWidth(80)
        self.port_entry.setStyleSheet(
            "QLineEdit{background:#f5f5f5; border:1px solid #e0e0e0; border-radius:6px;"
            "padding:6px 10px; font-size:15px;}"
            "QLineEdit:focus{border-color:#07C160;}"
        )
        header_layout.addWidget(self.port_entry)

        # 连接按钮
        self.btn_connect = QPushButton("连接设备")
        self.btn_connect.setFixedWidth(100)
        self.btn_connect.setStyleSheet(
            "QPushButton{background:#07C160; color:#ffffff; border:none;"
            "border-radius:6px; padding:8px 16px; font-weight:bold; font-size:15px;}"
            "QPushButton:hover{background:#06AD56;}"
        )
        self.btn_connect.clicked.connect(self._on_connect_clicked)
        header_layout.addWidget(self.btn_connect)

        header_layout.addStretch()

        # 时钟
        self.lbl_clock = QLabel("00:00:00")
        self.lbl_clock.setFont(QFont("Microsoft YaHei", 15))
        self.lbl_clock.setStyleSheet("color: #999999; border: none;")
        header_layout.addWidget(self.lbl_clock)

        header_layout.addSpacing(15)

        # 连接状态
        self.lbl_conn = QLabel("未连接")
        self.lbl_conn.setFont(QFont("Microsoft YaHei", 15))
        self.lbl_conn.setStyleSheet("color: #fa5151; border: none; font-weight: bold;")
        header_layout.addWidget(self.lbl_conn)

        # 时钟定时器
        self.clock_timer = QTimer()
        self.clock_timer.timeout.connect(self._update_clock)
        self.clock_timer.start(1000)
        self._update_clock()

        main_layout.addWidget(header)

        # ---------- 中间区域：左侧状态 + 右侧控制（可拖拽调整） ----------
        horizontal_splitter = QSplitter(Qt.Horizontal)
        horizontal_splitter.setStyleSheet("""
            QSplitter::handle {
                background-color: #e0e0e0;
            }
            QSplitter::handle:hover {
                background-color: #07C160;
            }
        """)
        horizontal_splitter.setHandleWidth(6)

        # ---- 左侧：状态面板 ----
        status_group = QGroupBox("系统状态")
        status_layout = QVBoxLayout(status_group)
        status_layout.setContentsMargins(8, 10, 8, 8)
        status_layout.setSpacing(0)

        status_items = [
            (0, "电机模式", "停止",   "#333333"),
            (1, "舵机模式", "—",      "#333333"),
            (2, "电位器",   "0 %",    "#333333"),
            (3, "舵机速度", "0 / 13", "#333333"),
            (4, "光纤传感器","未检测", "#333333"),
            (5, "速度模式", "就地",   "#07C160"),
            (6, "网络连接", "断开",   "#fa5151"),
        ]

        self.status_labels = {}
        for i, (row, name, default, color) in enumerate(status_items):
            row_container = QWidget()
            bg = "#f8f8f8" if i % 2 == 0 else "#ffffff"
            row_container.setStyleSheet(
                f"QWidget#row{i}{{background:{bg}; border:none; border-radius:0px;}}"
            )
            row_container.setObjectName(f"row{i}")

            row_layout = QHBoxLayout(row_container)
            row_layout.setContentsMargins(12, 0, 12, 0)
            row_layout.setAlignment(Qt.AlignCenter)

            lbl_name = QLabel(name)
            lbl_name.setStyleSheet("color: #333333; font-size: 16px; font-weight: bold; background:transparent;")
            lbl_name.setFixedWidth(110)
            lbl_name.setAlignment(Qt.AlignCenter)
            row_layout.addWidget(lbl_name)

            lbl_value = QLabel(default)
            lbl_value.setStyleSheet(f"color: {color}; font-size: 16px; font-weight: bold; background:transparent;")
            lbl_value.setAlignment(Qt.AlignCenter)
            row_layout.addWidget(lbl_value, stretch=1)

            self.status_labels[name] = lbl_value
            status_layout.addWidget(row_container, stretch=1)

        horizontal_splitter.addWidget(status_group)

        # ---- 右侧：控制面板（速度+设备） ----
        right_widget = QWidget()
        right_layout = QVBoxLayout(right_widget)
        right_layout.setContentsMargins(0, 0, 0, 0)
        right_layout.setSpacing(0)

        # -- 速度控制 --
        speed_group = QGroupBox("速度控制")
        speed_layout = QVBoxLayout(speed_group)
        speed_layout.setAlignment(Qt.AlignVCenter)

        slider_layout = QHBoxLayout()
        slider_layout.setAlignment(Qt.AlignVCenter)

        self.speed_slider = QSlider(Qt.Horizontal)
        self.speed_slider.setRange(0, 13)
        self.speed_slider.setValue(0)
        self.speed_slider.valueChanged.connect(self._on_slider_change)
        self.speed_slider.setMinimumHeight(30)
        slider_layout.addWidget(self.speed_slider, stretch=1)

        self.speed_entry = QLineEdit("0")
        self.speed_entry.setFixedWidth(55)
        self.speed_entry.setAlignment(Qt.AlignCenter)
        self.speed_entry.returnPressed.connect(self._on_entry_change)
        slider_layout.addWidget(self.speed_entry)

        speed_layout.addLayout(slider_layout)
        right_layout.addWidget(speed_group, stretch=0)

        # -- 设备控制 --
        ctrl_group = QGroupBox("设备控制")
        ctrl_grid = QGridLayout(ctrl_group)

        buttons = [
            (0, 0, "正转",  "#576B95", "#ffffff", "#4A5D84", "dj 1"),
            (0, 1, "反转",  "#576B95", "#ffffff", "#4A5D84", "dj 2"),
            (1, 0, "停止",  "#fa5151", "#ffffff", "#E04444", "dj 0"),
            (1, 1, "自动",  "#FFC300", "#333333", "#E6B000", "dj 3"),
            (2, 0, "解抱闸","#E67E22", "#ffffff", "#D35400", "en 0"),
            (2, 1, "上抱闸","#E67E22", "#ffffff", "#D35400", "en 1"),
        ]

        for row, col, text, bg, fg, hover, cmd in buttons:
            btn = QPushButton(text)
            btn.setStyleSheet(
                f"QPushButton{{background:{bg}; color:{fg}; border:none;"
                f"border-radius:6px; padding:12px; font-weight:bold; font-size:15px;}}"
                f"QPushButton:hover{{background:{hover};}}"
            )
            btn.setMinimumHeight(48)
            btn.clicked.connect(lambda checked, c=cmd: self._send_command(c))
            ctrl_grid.addWidget(btn, row, col)

        # -- 模式切换 --
        self.btn_mode = QPushButton("就地模式")
        self.btn_mode.setStyleSheet(
            "QPushButton{background:#07C160; color:#ffffff;"
            "border:none; border-radius:6px; padding:12px;"
            "font-weight:bold; font-size:16px;}"
            "QPushButton:hover{background:#06AD56;}"
        )
        self.btn_mode.setMinimumHeight(52)
        self.btn_mode.clicked.connect(self._toggle_mode)
        ctrl_grid.addWidget(self.btn_mode, 3, 0, 1, 2)

        right_layout.addWidget(ctrl_group, stretch=3)

        horizontal_splitter.addWidget(right_widget)
        horizontal_splitter.setSizes([400, 400])

        # ---------- 底部：指令输入 + 日志（可上下拉伸） ----------
        cmd_frame = QFrame()
        cmd_frame.setStyleSheet(
            "background-color: #ffffff;"
            "border: 1px solid #e0e0e0; border-radius: 8px;"
        )
        cmd_layout = QHBoxLayout(cmd_frame)
        cmd_layout.setContentsMargins(10, 10, 10, 10)
        cmd_layout.setAlignment(Qt.AlignVCenter)

        prompt = QLabel(">")
        prompt.setStyleSheet("color: #07C160; font-size: 18px; font-weight: bold; border: none;")
        cmd_layout.addWidget(prompt)

        self.cmd_entry = QLineEdit()
        self.cmd_entry.setPlaceholderText("输入指令，回车发送...")
        self.cmd_entry.returnPressed.connect(self._on_send_command)
        cmd_layout.addWidget(self.cmd_entry, stretch=1)

        btn_send = QPushButton("发送")
        btn_send.setFixedWidth(80)
        btn_send.setStyleSheet(
            "QPushButton{background:#07C160; color:#ffffff; border:none;"
            "border-radius:6px; padding:10px; font-weight:bold; font-size:15px;}"
            "QPushButton:hover{background:#06AD56;}"
        )
        btn_send.clicked.connect(self._on_send_command)
        cmd_layout.addWidget(btn_send)

        # -- 日志 --
        log_group = QGroupBox("通信日志")
        log_layout = QVBoxLayout(log_group)

        self.log_text = QTextEdit()
        self.log_text.setReadOnly(True)
        self.log_text.setFont(QFont("Microsoft YaHei", 13))
        log_layout.addWidget(self.log_text)

        # 纵向分割条：上半部分（状态+控制） vs 下半部分（指令+日志）
        vertical_splitter = QSplitter(Qt.Vertical)
        vertical_splitter.setStyleSheet("""
            QSplitter::handle {
                background-color: #e0e0e0;
                height: 3px;
            }
            QSplitter::handle:hover {
                background-color: #07C160;
            }
        """)
        vertical_splitter.setHandleWidth(6)

        # 上半部分：水平分割条
        vertical_splitter.addWidget(horizontal_splitter)

        # 下半部分：指令输入 + 日志
        bottom_widget = QWidget()
        bottom_layout = QVBoxLayout(bottom_widget)
        bottom_layout.setContentsMargins(0, 0, 0, 0)
        bottom_layout.setSpacing(8)
        bottom_layout.addWidget(cmd_frame)
        bottom_layout.addWidget(log_group, stretch=1)

        vertical_splitter.addWidget(bottom_widget)
        vertical_splitter.setSizes([500, 200])

        main_layout.addWidget(vertical_splitter, stretch=1)

    # ============ 时钟更新 ============
    def _update_clock(self):
        now = datetime.now().strftime("%H:%M:%S")
        self.lbl_clock.setText(now)

    # ============ 连接按钮点击 ============
    def _on_connect_clicked(self):
        """点连接按钮"""
        if self.client.is_connected():
            # 已连接 → 断开
            self.client.disconnect()
            self.lbl_conn.setText("未连接")
            self.lbl_conn.setStyleSheet("color: #fa5151; border: none; font-weight: bold;")
            self.status_labels["网络连接"].setText("断开")
            self.status_labels["网络连接"].setStyleSheet(
                "color: #fa5151; font-size: 16px; font-weight: bold;"
            )
            self.btn_connect.setText("连接设备")
            self.signals.log_message.emit("手动断开连接")
            return

        broker = self.broker_entry.text().strip()
        port_str = self.port_entry.text().strip()
        if not broker:
            QMessageBox.warning(self, "提示", "请输入Broker地址")
            return

        self.btn_connect.setEnabled(False)
        self.btn_connect.setText("连接中...")

        def do_connect():
            try:
                self.signals.log_message.emit(f"正在连接 {broker}:{port_str} ...")
                print(f"DEBUG: 连接 {broker}:{port_str}")
                result = self.client.connect(broker=broker, port=int(port_str) if port_str else None)
                print(f"DEBUG: 结果 = {result}")
                if result:
                    self.signals.connected.emit()
                else:
                    self.signals.connect_failed.emit(f"{broker}:{port_str}")
            except Exception as e:
                print(f"DEBUG: 异常 = {e}")
                self.signals.connect_failed.emit(f"{broker}:{port_str}")

        threading.Thread(target=do_connect, daemon=True).start()

    def _on_connected(self):
        self.lbl_conn.setText("已连接")
        self.lbl_conn.setStyleSheet("color: #07C160; border: none; font-weight: bold;")
        self.status_labels["网络连接"].setText("已连接")
        self.status_labels["网络连接"].setStyleSheet(
            "color: #07C160; font-size: 16px; font-weight: bold; background:transparent;"
        )
        self.btn_connect.setText("断开")
        self.btn_connect.setStyleSheet(
            "QPushButton{background:#fa5151; color:#ffffff; border:none;"
            "border-radius:6px; padding:8px 16px; font-weight:bold; font-size:15px;}"
            "QPushButton:hover{background:#E04444;}"
        )
        self.btn_connect.setEnabled(True)
        self.signals.log_message.emit(chr(34)+chr(67)+chr(111)+chr(110)+chr(110)+chr(101)+chr(99)+chr(116)+chr(101)+chr(100)+chr(33)+chr(34))

    def _on_connect_failed(self, addr):
        self.btn_connect.setText("连接设备")
        self.btn_connect.setStyleSheet(
            "QPushButton{background:#07C160; color:#ffffff; border:none;"
            "border-radius:6px; padding:8px 16px; font-weight:bold; font-size:15px;}"
            "QPushButton:hover{background:#06AD56;}"
        )
        self.btn_connect.setEnabled(True)

        reply = QMessageBox.question(
            self, "连接失败",
            f"无法连接到 {addr}\n\n是否重试？",
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.Yes
        )
        if reply == QMessageBox.Yes:
            self._on_connect_clicked()
        else:
            self.signals.log_message.emit(f"连接失败，已取消：{addr}")

    def _on_disconnected(self):
        self.lbl_conn.setText("未连接")
        self.lbl_conn.setStyleSheet("color: #fa5151; border: none; font-weight: bold;")
        self.status_labels["网络连接"].setText("断开")
        self.status_labels["网络连接"].setStyleSheet(
            "color: #fa5151; font-size: 16px; font-weight: bold; background:transparent;"
        )
        self.btn_connect.setText("连接设备")
        self.btn_connect.setStyleSheet(
            "QPushButton{background:#07C160; color:#ffffff; border:none;"
            "border-radius:6px; padding:8px 16px; font-weight:bold; font-size:15px;}"
            "QPushButton:hover{background:#06AD56;}"
        )
        self.btn_connect.setEnabled(True)
        self.signals.log_message.emit("连接断开")

    # ============ 状态轮询 ============
    # ============ 更新显示 ============
    def _update_display(self, data):
        old = self.current_data
        self.current_data = data

        state  = data.get("state", 0)
        speed  = data.get("speed", 0)
        pot    = data.get("pot", 0)
        sensor = data.get("sensor", 0)
        mode   = data.get("mode", 0)

        STATE_MAP = {
            0: ("停止", "#999999"),
            1: ("正转", "#07C160"),
            2: ("反转", "#576B95"),
            3: ("自动", "#FFC300"),
        }
        DIRECTION_MAP = {0: "—", 1: "顺时针", 2: "逆时针", 3: "传感器"}

        if state != old.get("state"):
            motor_text, color = STATE_MAP.get(state, ("未知", "#ffffff"))
            self.status_labels["电机模式"].setText(motor_text)
            self.status_labels["电机模式"].setStyleSheet(
                f"color: {color}; font-size: 16px; font-weight: bold; background:transparent;"
            )
            self.status_labels["舵机模式"].setText(DIRECTION_MAP.get(state, "—"))
            self.status_labels["舵机模式"].setStyleSheet(
                f"color: {color}; font-size: 16px; font-weight: bold; background:transparent;"
            )

        if pot != old.get("pot"):
            self.status_labels["电位器"].setText(f"{pot} %")

        if speed != old.get("speed"):
            self.status_labels["舵机速度"].setText(f"{speed} / 13")
            if self.speed_mode == 1:
                self.slider_updating = True
                self.speed_slider.setValue(speed)
                self.speed_entry.setText(str(speed))
                self.slider_updating = False

        if sensor != old.get("sensor"):
            if sensor == 0:
                self.status_labels["光纤传感器"].setText("检测到！")
                self.status_labels["光纤传感器"].setStyleSheet(
                    "color: #fa5151; font-size: 16px; font-weight: bold; background:transparent;"
                )
            else:
                self.status_labels["光纤传感器"].setText("未检测")
                self.status_labels["光纤传感器"].setStyleSheet(
                    "color: #333333; font-size: 16px; font-weight: bold; background:transparent;"
                )

        if mode != old.get("mode"):
            self.speed_mode = mode
            if mode == 0:
                self.btn_mode.setText("就地模式")
                self.btn_mode.setStyleSheet(
                    "QPushButton{background:#07C160; color:#ffffff;"
                    "border:none; border-radius:6px; padding:12px;"
                    "font-weight:bold; font-size:16px;}"
                    "QPushButton:hover{background:#06AD56;}"
                )
                self.status_labels["速度模式"].setText("就地")
                self.status_labels["速度模式"].setStyleSheet(
                    "color: #07C160; font-size: 16px; font-weight: bold; background:transparent;"
                )
            else:
                self.btn_mode.setText("远程模式")
                self.btn_mode.setStyleSheet(
                    "QPushButton{background:#07C160; color:#ffffff;"
                    "border:none; border-radius:6px; padding:12px;"
                    "font-weight:bold; font-size:16px;}"
                    "QPushButton:hover{background:#06AD56;}"
                )
                self.status_labels["速度模式"].setText("远程")
                self.status_labels["速度模式"].setStyleSheet(
                    "color: #576B95; font-size: 16px; font-weight: bold; background:transparent;"
                )

    # ============ 模式切换 ============
    def _toggle_mode(self):
        if not self.client.is_connected():
            self.signals.log_message.emit("未连接，无法切换模式")
            return
        if self.speed_mode == 0:
            self._send_command("mode remote")
        else:
            self._send_command("mode local")

    # ============ 滑块变化 ============
    def _on_slider_change(self, value):
        if self.slider_updating:
            return
        self.speed_entry.setText(str(value))
        if self.speed_mode == 1:
            self._send_command(f"speed {value}")

    # ============ 输入框变化 ============
    def _on_entry_change(self):
        try:
            val = int(self.speed_entry.text())
            val = max(0, min(13, val))
            self.slider_updating = True
            self.speed_slider.setValue(val)
            self.speed_entry.setText(str(val))
            self.slider_updating = False
            if self.speed_mode == 1:
                self._send_command(f"speed {val}")
        except ValueError:
            self.speed_entry.setText(str(self.current_data.get("speed", 0)))

    # ============ 发送命令 ============
    def _send_command(self, cmd):
        def do_send():
            response = self.client.send_cmd(cmd)
            if response is None:
                self.signals.disconnected.emit()
                return
            self.signals.log_message.emit(f"→ {cmd}")
            if response:
                self.signals.log_message.emit(f"← {response}")

        threading.Thread(target=do_send, daemon=True).start()

    # ============ 指令输入 ============
    def _on_send_command(self):
        cmd = self.cmd_entry.text().strip()
        if not cmd:
            return
        if not self.client.is_connected():
            self.signals.log_message.emit("未连接，无法发送指令")
            return
        self._send_command(cmd)
        self.cmd_entry.clear()

    # ============ 日志 ============
    def _append_log(self, message):
        now = datetime.now().strftime("%H:%M:%S")
        self.log_text.append(f"[{now}] {message}")
        scrollbar = self.log_text.verticalScrollBar()
        scrollbar.setValue(scrollbar.maximum())

    # ============ 快捷键 ============
    def keyPressEvent(self, event):
        if event.key() == Qt.Key_Escape:
            self.close()


# ============================================================
#  主程序入口
# ============================================================
if __name__ == "__main__":
    app = QApplication([])

    palette = QPalette()
    palette.setColor(QPalette.Window, QColor("#ededed"))
    palette.setColor(QPalette.WindowText, QColor("#333333"))
    palette.setColor(QPalette.Base, QColor("#ffffff"))
    palette.setColor(QPalette.Text, QColor("#333333"))
    palette.setColor(QPalette.Button, QColor("#ffffff"))
    palette.setColor(QPalette.ButtonText, QColor("#333333"))
    app.setPalette(palette)

    window = ESP32MainWindow()
    window.showMaximized()
    app.exec_()
